<template>
  <div id="app">
    <router-link to="/">首页</router-link>
    <router-link to="/NeiRong">设备列表</router-link>
    <router-view></router-view>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>