<template>
  <div>
    <ul>
      <li>传感器1</li>
      <li>传感器2</li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'NeiRong',
}
</script>
