<template>
  <div>
    <h1>欢迎使用本系统，此处为首页内容</h1>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
}
</script>
