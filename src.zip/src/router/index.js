import { createRouter, createWebHistory } from 'vue-router' 
import HelloWorld from '../components/HelloWorld.vue'
import NeiRong from '../components/NeiRong.vue'

const routes = [
  {
    path: '/',
    component: HelloWorld
  },
  {
    path: '/NeiRong',
    component: NeiRong
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})
export default router